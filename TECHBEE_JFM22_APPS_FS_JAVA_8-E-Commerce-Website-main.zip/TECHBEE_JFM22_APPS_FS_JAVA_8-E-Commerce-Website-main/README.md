# TECHBEE_JFM22_APPS_FS_JAVA_8-E-Commerce-Website
This is an e-commerce website which is made using spring boot and mysql.




Home Page
![home page](https://user-images.githubusercontent.com/108517129/177129926-0c2dd4e0-0348-4e3a-9719-9afe416364c4.PNG)
Categories![storecategoriesBrandsSize](https://user-images.githubusercontent.com/108517129/177130097-ffdadfb2-4052-4614-bb34-47a8d1355175.PNG)
login & Register
![login Register](https://user-images.githubusercontent.com/108517129/177130150-ed894189-9869-498b-b081-144f0b5ac63b.PNG)
user-profile
![my-profile-section](https://user-images.githubusercontent.com/108517129/177130203-bc39dc3c-a96d-4762-a47a-5547c24e1e02.PNG)
admin-add-product
![adminArticle Ad](https://user-images.githubusercontent.com/108517129/177130261-42e4a3c3-37ad-42b3-9aa6-c4198232baba.PNG)

